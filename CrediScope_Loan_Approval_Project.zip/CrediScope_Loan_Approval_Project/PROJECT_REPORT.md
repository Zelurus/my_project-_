# SMLDS Mini Project Report

## Loan Approval Prediction Using Machine Learning

### 1. Abstract

This project develops **CrediScope**, an interactive desktop-browser application that demonstrates loan-status prediction as a binary classification problem. It provides exploratory data analysis (EDA), dataset-quality checks, preprocessing, model comparison, evaluation plots, and a prediction form. The bundled dataset is synthetic and is used only to make the complete workflow reproducible without exposing personal financial data.

### 2. Problem Statement

Loan application records contain numerical and categorical attributes. This project studies whether supervised learning classifiers can learn associations from labelled examples and estimate an application’s historical status category. The model is an educational decision-support prototype, not a real lending system.

### 3. Aim and Objectives

**Aim:** To create a working application for loan approval classification using machine learning.

**Objectives:**

1. Select and describe a suitable labelled dataset and its target variable.
2. Perform EDA and inspect missing values, duplicates, class balance, and feature patterns.
3. Apply preprocessing to numerical and categorical features.
4. Split the dataset into training and testing partitions.
5. Train and compare Logistic Regression and Random Forest.
6. Evaluate using accuracy, precision, recall, F1-score, ROC-AUC, confusion matrix, and ROC curve.
7. Build an interactive interface for new applicant predictions and communicate the limitations clearly.

### 4. Dataset Description and Source

The bundled file is `data/loan_applications.csv`, containing **800 synthetic application records** and 13 columns. The dataset is generated deterministically by `scripts/generate_demo_data.py` with random seed 42. It intentionally contains missing feature values so that the data-quality and imputation steps can be demonstrated. It is not a real bank dataset, and the generated labels do not represent a bank’s lending policy.

The schema is based on common educational loan-prediction fields, including gender, marital status, dependents, education, self-employment, applicant income, co-applicant income, loan amount, loan term, credit history, and property area. The target variable is **`Loan_Status`**, normalized by the app as **Approved** or **Rejected**. `Loan_ID` is an identifier and is excluded from model features.

**Source statement:** Default demo data source — the reproducible data generator in this project: `scripts/generate_demo_data.py`. Schema reference — [Analytics Vidhya Loan Prediction Problem](https://datahack.analyticsvidhya.com/contest/practice-problem-loan-prediction-iii/) and [public GitHub schema mirror](https://github.com/shrikant-temburwar/Loan-Prediction-Dataset). The real benchmark data is not included in the project ZIP.

### 5. Exploratory Data Analysis

The dashboard provides these EDA views:

- Loan-status distribution to compare the number and share of approved and rejected rows.
- Approval share by credit history to explore association between a categorical input and target class.
- Applicant/co-applicant income versus requested loan amount, coloured by observed status.
- Missing values by feature, exact duplicate rows, repeated profiles excluding `Loan_ID`, and numeric summary statistics.

On the included data, there are 800 rows and 13 columns, 526 approved labels, 274 rejected labels, no exact duplicate rows, and 178 missing feature cells. The largest missing-value count is in `Credit_History` (55 cells). These statistics describe the generated demo file; re-run the app or notebook to inspect values for another uploaded dataset.

### 6. Preprocessing and Methodology

The workflow is:

**Dataset → EDA → Preprocessing → Train/Test Split → ML Model → Evaluation → Results → Conclusion**

A stratified 75/25 train/test split is used. Missing numerical values are imputed using the median and categorical values using the most frequent value. Numerical attributes are standardized, and categorical attributes are one-hot encoded. These operations are placed inside a scikit-learn `Pipeline` and fitted on training data to reduce preprocessing leakage.

Two classifiers are compared:

- **Logistic Regression:** a linear classification model that estimates class probabilities.
- **Random Forest:** an ensemble of decision trees that can capture non-linear patterns and interactions.

The candidates are compared by mean F1-score under stratified cross-validation on the training split. The selected pipeline is then evaluated on the held-out test set, which is not used to select the winner.

### 7. Evaluation Metrics

- **Accuracy:** proportion of test rows classified correctly.
- **Precision:** among rows predicted Approved, the proportion labelled Approved.
- **Recall:** among actual Approved rows, the proportion identified by the model.
- **F1-score:** harmonic mean of precision and recall.
- **ROC-AUC:** measures ranking quality across decision thresholds.
- **Confusion matrix:** summarizes true/false positives and true/false negatives.

### 8. Results and Findings

The app calculates metrics at runtime and shows them in the **Model Performance** page. In one run using the bundled demo data and current local package versions, Random Forest was selected by training cross-validation; test accuracy was approximately 0.725, F1-score approximately 0.806, and ROC-AUC approximately 0.672. Your displayed values may vary slightly with library versions or a different uploaded dataset; use the values shown in your own run for your final submission.

The generated outcome labels intentionally contain noise, so perfect scores are neither expected nor desirable. Feature importance and EDA plots describe associations in this synthetic dataset, not causes or general rules for granting loans.

### 9. Limitations and Ethical Considerations

1. The bundled data is synthetic and does not establish real-world model performance.
2. Simulated or public historical approval labels can contain bias, sampling issues, and outdated practices.
3. Feature importance does not prove causality.
4. Probabilities from this demo are not guaranteed to be calibrated.
5. A real credit product would require lawful and representative data, privacy controls, bias/fairness evaluation, robust external validation, calibration, monitoring, explainability, legal review, and human oversight.

### 10. Conclusion

CrediScope demonstrates an end-to-end classification project in an accessible interface. It covers data inspection, preprocessing, model training and comparison, performance evaluation, and a new-applicant prediction form. It fulfills the main workflow requirements of the SMLDS mini project while explicitly identifying the synthetic dataset and the limits of interpreting its metrics.

### 11. References

1. Analytics Vidhya, [Loan Prediction Problem](https://datahack.analyticsvidhya.com/contest/practice-problem-loan-prediction-iii/) — schema reference.
2. Public schema mirror: [Loan-Prediction-Dataset on GitHub](https://github.com/shrikant-temburwar/Loan-Prediction-Dataset).
3. Streamlit documentation, [Install Streamlit](https://docs.streamlit.io/get-started/installation) and [Run your app](https://docs.streamlit.io/develop/concepts/architecture/run-your-app).
4. Scikit-learn documentation, [Pipelines and composite estimators](https://scikit-learn.org/stable/modules/compose.html) and [Model evaluation](https://scikit-learn.org/stable/modules/model_evaluation.html).
