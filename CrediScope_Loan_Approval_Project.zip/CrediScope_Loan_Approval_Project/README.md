# CrediScope — Loan Approval Prediction

**SMLDS mini project · Binary classification · Streamlit desktop web app**

CrediScope demonstrates an end-to-end machine-learning workflow: dataset validation, exploratory data analysis, missing-value checks, preprocessing, training/test split, model comparison, prediction, and evaluation in an interactive interface.

> **Important:** The bundled `data/loan_applications.csv` is a **synthetic educational dataset** created by `scripts/generate_demo_data.py`. It is generated with simulated patterns and noise; it is not real bank/customer data, and it must not be used for actual lending decisions. The reported metrics are demonstrations of the project workflow, not evidence of real-world creditworthiness or fairness.

## What is included?

- **Overview:** application counts, approval split, approval share by credit history, and income-versus-loan plot.
- **Explore Data:** missing values, exact duplicates, repeated-profile diagnostic, numeric summary, filters, data preview, CSV download.
- **Predict Application:** interactive applicant form that calls a trained backend model.
- **Model Performance:** Logistic Regression and Random Forest comparison, cross-validation scores, accuracy, precision, recall, F1, ROC-AUC, confusion matrix, ROC curve, and feature importance/coefficient chart.
- **Project Guide:** objective, workflow, model explanations, limitations, and viva notes.
- **Jupyter notebook:** `notebooks/Loan_Approval_Analysis.ipynb` for a reproducible EDA/model walkthrough.
- **Offline-ready starter dataset:** 800 synthetic rows with missing values, so you can run the app immediately after installing packages.

## Tech stack

Python, Streamlit, Pandas, NumPy, Scikit-learn, Plotly, and Jupyter Notebook.

## Run on Windows (desktop)

You do not need to build a separate `.exe`. Streamlit runs the Python backend locally and opens the frontend in your desktop browser. The app is available at `http://localhost:8501` while the server is running.

1. Install **Python 3.11 or 3.12 (64-bit)** from [python.org](https://www.python.org/downloads/). During setup, enable **Add Python to PATH**.
2. Extract this project ZIP to a folder, e.g. `C:\Users\YourName\Documents\CrediScope_Project`.
3. Open that folder in File Explorer. Click the address bar, type `cmd`, and press Enter.
4. Create a virtual environment:

   ```bat
   py -m venv .venv
   ```

5. Activate it:

   ```bat
   .venv\Scripts\activate
   ```

6. Install requirements:

   ```bat
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```

7. Run the app:

   ```bat
   python -m streamlit run app.py
   ```

   A browser tab should open. If it does not, open `http://localhost:8501` manually.

**Next time:** open the project folder in Command Prompt, activate `.venv`, then run `python -m streamlit run app.py`. You can also double-click `run_app.bat` after completing the installation steps above.

To stop the server, click the terminal and press `Ctrl+C`.

## Run the notebook

With the same virtual environment activated:

```bat
jupyter notebook
```

Open `notebooks/Loan_Approval_Analysis.ipynb` and run the cells from top to bottom. The notebook reads the included CSV.

## Dataset source and compatible external datasets

- **Default dataset source:** synthetic data generated reproducibly from this repository's [`scripts/generate_demo_data.py`](scripts/generate_demo_data.py), with a fixed random seed. It is intentionally self-contained so the project works immediately without downloading customer data.
- **Schema/reference dataset:** [Analytics Vidhya — Loan Prediction Problem](https://datahack.analyticsvidhya.com/contest/practice-problem-loan-prediction-iii/), also publicly described in [this GitHub mirror](https://github.com/shrikant-temburwar/Loan-Prediction-Dataset). The classic schema contains fields such as `ApplicantIncome`, `CoapplicantIncome`, `LoanAmount`, `Loan_Amount_Term`, `Credit_History`, `Property_Area`, and target `Loan_Status`.
- The project **does not bundle the above real benchmark records**. If you want to use that public reference dataset for your submission, run `python scripts/download_reference_dataset.py` in a terminal with internet access. This saves `data/loan_applications_public.csv` without overwriting the synthetic demo. Then choose that file in the app's sidebar uploader. Alternatively, download the [raw CSV directly](https://raw.githubusercontent.com/shrikant-temburwar/Loan-Prediction-Dataset/master/train.csv) and upload it. Review upstream terms before redistribution. The app accepts target values `Y/N`, `Yes/No`, `1/0`, and `Approved/Rejected`.
- The input CSV should contain these required columns: `Gender`, `Married`, `Dependents`, `Education`, `Self_Employed`, `ApplicantIncome`, `CoapplicantIncome`, `LoanAmount`, `Loan_Amount_Term`, `Credit_History`, `Property_Area`, and `Loan_Status`. An optional `Loan_ID` column is treated as an identifier, not a model feature.

The public benchmark schema is provided as a reference, not as the data source for the synthetic demo rows. Review the terms of any external dataset before redistribution.

## Methodology

1. Validate required columns and normalize the target label.
2. Inspect class distribution, missing values, exact duplicate rows, repeated profiles, and numeric summaries.
3. Split data into stratified **75% training / 25% test** partitions.
4. Impute numerical values with the training median and categorical values with the training most-frequent value.
5. Standardize numeric features and one-hot encode categories using a scikit-learn `Pipeline` / `ColumnTransformer`.
6. Compare **Logistic Regression** and **Random Forest** using stratified cross-validation on the training set.
7. Select the model by mean cross-validation F1-score, then report final test-set metrics separately.
8. Use the fitted pipeline to predict the class and probability for a new form submission.

The test partition is not used to select the winner. This is more defensible than choosing a model by its score on the same test data used for reporting.

## Common fixes

- **`py` is not recognized:** reinstall Python and enable “Add Python to PATH”, or try `python -m venv .venv`.
- **`streamlit` command is not recognized:** activate `.venv`, then run `python -m pip install -r requirements.txt` and launch with `python -m streamlit run app.py`.
- **Missing columns error:** your CSV must have all required fields listed above; extra fields such as `Loan_ID` are allowed.
- **Port 8501 is busy:** run `python -m streamlit run app.py --server.port 8502` and open `http://localhost:8502`.
- **You changed the dataset but metrics did not update:** Streamlit uses caching for speed; change the file and re-upload it or click **Clear cache** from the app's menu, then rerun.

## Upload to GitHub

1. Sign in to GitHub and create a new public repository named `cred-scope-loan-approval` without a README template (or keep your preferred repository name).
2. Upload the *contents* of this folder, keeping the `data`, `notebooks`, and `scripts` directories.
3. Suggested repository description: *“CrediScope: an interactive SMLDS loan-approval classification demo with EDA, model comparison, and Streamlit UI.”*
4. Add screenshots from the running app in a `screenshots/` folder after you test it. Use your own screenshots rather than presenting a mock-up as a running application.
5. For a public web demo, Streamlit Community Cloud can deploy from a GitHub repository: [official deployment guide](https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app). Do not upload personal data or secrets.

## Viva-ready summary

- **Title:** Loan Approval Prediction Using Machine Learning.
- **Aim:** Develop an interactive classification application to estimate the loan-status class from applicant attributes.
- **Target:** `Loan_Status` (Approved/Rejected).
- **Algorithms:** Logistic Regression and Random Forest.
- **Preprocessing:** median/mode imputation, standardization, one-hot encoding.
- **Evaluation:** accuracy, precision, recall, F1-score, ROC-AUC, confusion matrix, and ROC curve.
- **Conclusion:** The project demonstrates a complete ML interface from data exploration through model evaluation and applicant prediction. Real deployment would require suitable verified data, bias/fairness tests, legal and privacy review, calibration, governance, and human oversight.
