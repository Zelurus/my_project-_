# Start Here — CrediScope

Welcome! You do not need to understand every line of Python before running the project. Start the app first, then explore one section at a time.

## Run it on your Windows laptop

1. Install Python 3.11 or 3.12 from https://www.python.org/downloads/ and tick **Add Python to PATH** during setup.
2. Extract `CrediScope_Loan_Approval_Project.zip` into a normal folder.
3. Open that folder, click the File Explorer address bar, type `cmd`, and press Enter.
4. Enter these commands one by one:

   ```bat
   py -m venv .venv
   .venv\Scripts\activate
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   python -m streamlit run app.py
   ```

5. A browser should open to `http://localhost:8501`. This is the frontend. The Python files are the backend.
6. Keep the terminal open while using the app. To stop it, press `Ctrl+C` in the terminal.

The app and dataset are in the project folder. It does not need API keys or a database.

**If your teacher requires a real public dataset:** while internet is available, run `python scripts/download_reference_dataset.py` from the project folder, then in the app sidebar upload `data/loan_applications_public.csv`. This does not overwrite the synthetic starter data. The dataset source and terms are described in README.md.

## What each file does

- `app.py` — pages, form inputs, charts, and the user interface.
- `model_utils.py` — data validation, preprocessing pipeline, training, evaluation, and predictions.
- `data/loan_applications.csv` — bundled synthetic records so the app runs immediately.
- `scripts/generate_demo_data.py` — reproducibly creates the synthetic sample dataset.
- `scripts/download_reference_dataset.py` — downloads an optional public reference CSV if you have internet access.
- `notebooks/Loan_Approval_Analysis.ipynb` — notebook for EDA and model evaluation.
- `PROJECT_REPORT.md` — draft report structure and current example results.
- `requirements.txt` — the Python packages that must be installed.
- `run_app.bat` — optional launcher after dependencies have been installed.

## What to demonstrate to your teacher

1. **Overview:** show the target distribution and the EDA graphs.
2. **Explore Data:** explain missing values and duplicate checks.
3. **Predict Application:** enter a sample applicant and submit the form.
4. **Model Performance:** explain cross-validation, the test split, F1, ROC-AUC, and confusion matrix.
5. **Project Guide:** use the methodology and viva notes to explain the workflow.

## How to explain the ML pipeline in 30 seconds

“The project treats loan status as a binary classification task. It validates the dataset, checks missing values and patterns, and creates a stratified 75/25 train/test split. Numerical missing values are imputed with the median and categorical missing values with the most frequent value. Numeric features are standardized and categories are one-hot encoded inside a pipeline. Logistic Regression and Random Forest are compared using cross-validation on the training split. The selected model is evaluated on the held-out test set using accuracy, precision, recall, F1-score, ROC-AUC, and a confusion matrix. The Streamlit interface lets a user enter applicant details and view a model estimate.”

## Important before submission

The included CSV is synthetic, not actual bank data. The report identifies that clearly. If your teacher requires a real dataset, use the upload control with a compatible public, labelled dataset and update the report's dataset description and results to match the actual file you use.
