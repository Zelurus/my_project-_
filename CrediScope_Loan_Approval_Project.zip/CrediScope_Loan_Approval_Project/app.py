from pathlib import Path
import io

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from sklearn.metrics import confusion_matrix, roc_curve

from model_utils import (
    FEATURE_COLUMNS,
    TARGET,
    get_feature_importance,
    load_dataset,
    normalize_dataset,
    predict_applicant,
    train_evaluate_model,
    validate_dataset,
)

st.set_page_config(
    page_title="CrediScope | Loan Analytics",
    page_icon="🏦",
    layout="wide",
    initial_sidebar_state="expanded",
)

ROOT = Path(__file__).parent
DEFAULT_DATA = ROOT / "data" / "loan_applications.csv"

# Custom styling: responsive cards, a clean navy header, and legible typography.
st.markdown(
    """
    <style>
      @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap');
      html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }
      .block-container { padding-top: 1.35rem; padding-bottom: 2.6rem; max-width: 1500px; }
      [data-testid="stSidebar"] { border-right: 1px solid rgba(100,116,139,.18); }
      .hero {
        padding: 1.8rem 2rem; border-radius: 22px; color: #f8fafc;
        background: radial-gradient(circle at 86% 12%, rgba(34,211,238,.28), transparent 26%),
                    linear-gradient(120deg, #0b1225 0%, #182a52 58%, #3446a5 100%);
        margin-bottom: 1.25rem; box-shadow: 0 18px 40px rgba(15,23,42,.12);
      }
      .hero h1 { color: #fff; font-family: 'Manrope',sans-serif; font-size: clamp(1.8rem, 3vw, 2.55rem); letter-spacing: -.04em; margin: .25rem 0 .45rem 0; }
      .hero p { color: #dbeafe; font-size: 1rem; margin: 0; max-width: 850px; }
      .eyebrow { text-transform: uppercase; letter-spacing: .13em; font-size: .72rem; font-weight: 800; color: #67e8f9; }
      .pill-row { display: flex; gap: .5rem; flex-wrap: wrap; margin-top: 1rem; }
      .pill { font-size: .76rem; padding: .32rem .68rem; border-radius: 999px; border: 1px solid rgba(219,234,254,.24); background: rgba(255,255,255,.075); color: #e0f2fe; }
      .section-intro { color: #64748b; margin-top: -.35rem; margin-bottom: 1rem; }
      .insight { border: 1px solid #dbeafe; background: #f8fbff; padding: 1rem 1.1rem; border-radius: 14px; color: #1e293b; }
      .insight b { color: #1d4ed8; }
      .small-muted { color: #64748b; font-size: .83rem; }
      div[data-testid="stMetric"] { border: 1px solid rgba(148,163,184,.26); padding: 1rem 1.1rem; border-radius: 16px; background: linear-gradient(145deg,#ffffff,#f8fafc); box-shadow: 0 5px 18px rgba(15,23,42,.035); }
      div[data-testid="stMetricLabel"] p { color: #64748b; font-weight: 600; }
      div[data-testid="stMetricValue"] { color: #0f172a; font-family: 'Manrope',sans-serif; }
      div[data-testid="stForm"] { border: 1px solid #dbeafe; padding: 1.25rem; border-radius: 18px; }
      div.stButton > button[kind="primary"], div[data-testid="stFormSubmitButton"] button[kind="primary"] { border-radius: 10px; font-weight: 700; min-height: 2.8rem; }
      h1, h2, h3 { font-family: 'Manrope',sans-serif; letter-spacing: -.025em; }
      .stTabs [data-baseweb="tab"] { font-weight: 700; }
      @media (max-width: 700px) { .hero { padding: 1.25rem; } .block-container { padding-left: 1rem; padding-right: 1rem; } }
    </style>
    """,
    unsafe_allow_html=True,
)


def hero():
    st.markdown(
        """
        <div class="hero">
          <div class="eyebrow">SMLDS · Mini Project</div>
          <h1>CrediScope <span style="color:#67e8f9">/</span> Loan Approval Analytics</h1>
          <p>An end-to-end classification demo: explore applicant data, compare models, and test a prediction through a polished interactive interface.</p>
          <div class="pill-row">
            <span class="pill">Python + Scikit-learn</span>
            <span class="pill">Classification</span>
            <span class="pill">EDA + Model Evaluation</span>
            <span class="pill">Educational prototype</span>
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def currency_like(value):
    try:
        return f"{float(value):,.0f}"
    except (TypeError, ValueError):
        return "—"


@st.cache_resource(show_spinner="Training the models and evaluating them fairly…")
def cached_train(data: pd.DataFrame):
    model, metrics, X_test, y_test, y_pred, y_prob, comparison = train_evaluate_model(data)
    importance = get_feature_importance(model)
    cm = confusion_matrix(y_test, y_pred, labels=["Rejected", "Approved"])
    return model, metrics, X_test, y_test, y_pred, y_prob, comparison, importance, cm


with st.sidebar:
    st.markdown("# 🏦 CrediScope")
    st.caption("Loan approval · SMLDS mini project")
    page = st.radio(
        "NAVIGATION",
        ["Overview", "Explore Data", "Predict Application", "Model Performance", "Project Guide"],
        index=0,
        label_visibility="visible",
    )
    st.divider()
    st.markdown("**Dataset source**")
    uploaded = st.file_uploader(
        "Upload a compatible CSV (optional)",
        type=["csv"],
        help="Expected: the 11 feature columns plus Loan_Status. Y/N, 1/0, and Approved/Rejected targets are supported.",
    )
    st.caption("The included data is synthetic and generated for this classroom demonstration.")
    st.divider()
    st.markdown("<span class='small-muted'>Built for reproducible learning, not real credit decisions.</span>", unsafe_allow_html=True)

try:
    if uploaded is not None:
        raw_data = pd.read_csv(uploaded)
        source_label = f"Uploaded file · {uploaded.name}"
    else:
        if not DEFAULT_DATA.exists():
            st.error("The demo dataset is missing. Run scripts/generate_demo_data.py or restore data/loan_applications.csv.")
            st.stop()
        raw_data = load_dataset(str(DEFAULT_DATA))
        source_label = "Bundled synthetic demo dataset"

    data = normalize_dataset(raw_data)
    validate_dataset(data)
except Exception as exc:
    st.error(f"Dataset could not be loaded: {exc}")
    st.info("Check the required columns in the README, then upload a compatible CSV.")
    st.stop()

try:
    model, metrics, X_test, y_test, y_pred, y_prob, comparison, importance, cm = cached_train(data)
except Exception as exc:
    st.error(f"Model training failed: {exc}")
    st.info("The dataset may be too small, may contain only one target class, or may have an incompatible schema.")
    st.stop()

if page == "Overview":
    hero()
    st.subheader("Portfolio snapshot")
    st.markdown(f"<div class='section-intro'>Source: {source_label} · {len(data):,} application records · {len(data.columns)} columns</div>", unsafe_allow_html=True)

    total = len(data)
    approved_count = int((data[TARGET] == "Approved").sum())
    rejected_count = int((data[TARGET] == "Rejected").sum())
    approval_share = 100 * approved_count / total if total else 0
    missing_cells = int(data.isna().sum().sum())

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Applications", f"{total:,}")
    c2.metric("Approved in data", f"{approved_count:,}", help="Historical/simulated target labels in the loaded dataset.")
    c3.metric("Approval share", f"{approval_share:.1f}%")
    c4.metric("Missing cells", f"{missing_cells:,}")

    left, right = st.columns([1, 1.15], gap="large")
    with left:
        st.markdown("### Loan status mix")
        status_df = data[TARGET].value_counts().rename_axis("Status").reset_index(name="Applications")
        fig = px.pie(
            status_df,
            names="Status",
            values="Applications",
            hole=0.66,
            color="Status",
            color_discrete_map={"Approved": "#2563eb", "Rejected": "#f97316"},
        )
        fig.update_traces(textposition="inside", textinfo="percent+label", marker=dict(line=dict(color="white", width=3)))
        fig.update_layout(margin=dict(l=10, r=10, t=8, b=8), legend_title_text="", height=330, showlegend=False)
        st.plotly_chart(fig, use_container_width=True)
    with right:
        st.markdown("### Approval share by credit history")
        plot_data = data.copy()
        plot_data["Credit history"] = plot_data["Credit_History"].map({1.0: "Good history", 0.0: "No / poor history"}).fillna("Missing")
        plot_data["Approved flag"] = (plot_data[TARGET] == "Approved").astype(int)
        rate_data = plot_data.groupby("Credit history", as_index=False).agg(
            Applications=(TARGET, "size"), Approval_rate=("Approved flag", "mean")
        )
        rate_data["Approval rate"] = rate_data["Approval_rate"] * 100
        fig = px.bar(
            rate_data,
            x="Credit history",
            y="Approval rate",
            text=rate_data["Approval rate"].map(lambda v: f"{v:.1f}%"),
            color="Credit history",
            color_discrete_sequence=["#14b8a6", "#818cf8", "#94a3b8"],
            hover_data={"Applications": True, "Approval_rate": False, "Approval rate": ":.1f"},
        )
        fig.update_traces(textposition="outside", cliponaxis=False)
        fig.update_layout(yaxis_title="Approved applications (%)", xaxis_title="", showlegend=False, height=330, margin=dict(l=8, r=8, t=20, b=10), yaxis_range=[0, 100])
        st.plotly_chart(fig, use_container_width=True)

    st.markdown("### Applicant income vs. requested loan")
    scatter = data.copy()
    scatter["Total applicant income"] = scatter["ApplicantIncome"].fillna(0) + scatter["CoapplicantIncome"].fillna(0)
    fig = px.scatter(
        scatter,
        x="Total applicant income",
        y="LoanAmount",
        color=TARGET,
        color_discrete_map={"Approved": "#2563eb", "Rejected": "#f97316"},
        hover_data=["Loan_ID", "Property_Area", "Credit_History"],
        opacity=0.72,
        labels={"Total applicant income": "Applicant + co-applicant income", "LoanAmount": "Requested loan amount (dataset units)"},
    )
    fig.update_layout(height=380, legend_title_text="Observed status", margin=dict(l=8, r=8, t=20, b=8))
    st.plotly_chart(fig, use_container_width=True)

    st.markdown(
        f"<div class='insight'><b>Model snapshot:</b> {metrics['model_name']} was selected using {metrics['cv_folds']}-fold cross-validation on the training split. Its held-out test F1-score is <b>{metrics['f1']:.3f}</b> and ROC-AUC is <b>{metrics['roc_auc']:.3f}</b>. These values describe this loaded dataset only.</div>",
        unsafe_allow_html=True,
    )
    st.caption("Important: the bundled dataset is synthetic, generated with simulated patterns and noise. Its scores demonstrate the code workflow, not how a bank should make lending decisions.")

elif page == "Explore Data":
    hero()
    st.subheader("Explore the dataset")
    st.markdown("<div class='section-intro'>Inspect the raw features, data quality, target balance, and numerical patterns before modeling.</div>", unsafe_allow_html=True)

    duplicate_rows = int(data.duplicated().sum())
    # Loan_ID is an identifier; this second diagnostic detects repeated profiles independent of ID.
    profile_cols = [col for col in data.columns if col != "Loan_ID"]
    repeated_profiles = int(data[profile_cols].duplicated().sum()) if profile_cols else 0
    null_cells = int(data.isna().sum().sum())
    d1, d2, d3, d4 = st.columns(4)
    d1.metric("Rows", f"{len(data):,}")
    d2.metric("Columns", len(data.columns))
    d3.metric("Missing cells", f"{null_cells:,}")
    d4.metric("Exact duplicate rows", f"{duplicate_rows:,}")
    st.caption(f"Repeated profiles after excluding Loan_ID: {repeated_profiles:,}. Similar profiles can still represent separate applications, so they are reported rather than automatically deleted.")

    left, right = st.columns(2, gap="large")
    with left:
        st.markdown("### Missing values by column")
        missing_df = data.isna().sum().rename_axis("Column").reset_index(name="Missing values")
        missing_df = missing_df[missing_df["Missing values"] > 0].sort_values("Missing values", ascending=True)
        if len(missing_df):
            fig = px.bar(missing_df, x="Missing values", y="Column", orientation="h", text="Missing values", color="Missing values", color_continuous_scale=["#bae6fd", "#4f46e5"])
            fig.update_layout(height=360, coloraxis_showscale=False, margin=dict(l=8, r=10, t=10, b=8))
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.success("No missing values found in this dataset.")
    with right:
        st.markdown("### Numerical summary")
        numeric_summary = data.select_dtypes(include=np.number).describe().T
        st.dataframe(numeric_summary.round(2), use_container_width=True)

    st.markdown("### Filter and preview applications")
    f1, f2 = st.columns(2)
    with f1:
        selected_status = st.multiselect("Observed status", options=["Approved", "Rejected"], default=["Approved", "Rejected"])
    with f2:
        area_options = sorted(data["Property_Area"].dropna().unique().tolist())
        selected_area = st.multiselect("Property area", options=area_options, default=area_options)
    filtered = data[data[TARGET].isin(selected_status) & data["Property_Area"].isin(selected_area)]
    st.dataframe(filtered.head(250), use_container_width=True, hide_index=True)
    st.caption(f"Showing {min(len(filtered), 250):,} of {len(filtered):,} matching rows (maximum preview: 250).")

    csv_bytes = filtered.to_csv(index=False).encode("utf-8")
    st.download_button("Download filtered data as CSV", csv_bytes, file_name="cred_scope_filtered_applications.csv", mime="text/csv")

    st.markdown("### EDA observations to report")
    st.write(f"- The target contains {approved_count if page == 'Overview' else int((data[TARGET] == 'Approved').sum()):,} approved applications and {int((data[TARGET] == 'Rejected').sum()):,} rejected applications.")
    if null_cells:
        top_missing = data.isna().sum().sort_values(ascending=False)
        top_missing = top_missing[top_missing > 0]
        st.write(f"- The column with the most missing values is **{top_missing.index[0]}** ({int(top_missing.iloc[0])} missing entries). Missing values are handled by imputers inside the model pipeline.")
    st.write("- The status distribution, missing-value bar chart, income/loan scatter plot, and credit-history approval chart provide suitable basic EDA evidence for the report.")

elif page == "Predict Application":
    hero()
    st.subheader("Try a sample applicant")
    st.markdown("<div class='section-intro'>Enter the requested fields and run the trained classifier. The output is a model estimate, not an actual lending decision.</div>", unsafe_allow_html=True)

    with st.form("applicant_form", clear_on_submit=False):
        st.markdown("#### Applicant profile")
        p1, p2, p3 = st.columns(3)
        with p1:
            gender = st.selectbox("Gender", ["Male", "Female"])
            married = st.selectbox("Married", ["Yes", "No"])
            dependents = st.selectbox("Dependents", ["0", "1", "2", "3+"])
            education = st.selectbox("Education", ["Graduate", "Not Graduate"])
        with p2:
            self_employed = st.selectbox("Self-employed", ["No", "Yes"])
            property_area = st.selectbox("Property area", ["Semiurban", "Urban", "Rural"])
            credit_history_choice = st.selectbox("Credit history", ["Meets guideline (1)", "Does not meet guideline (0)"])
        with p3:
            applicant_income = st.number_input("Applicant income (dataset units)", min_value=0, max_value=200000, value=5500, step=250)
            coapplicant_income = st.number_input("Co-applicant income (dataset units)", min_value=0, max_value=200000, value=1500, step=250)
            loan_amount = st.number_input("Requested loan (thousands, dataset convention)", min_value=1, max_value=1000, value=140, step=10)
            loan_term = st.selectbox("Loan term (months)", [60, 120, 180, 240, 300, 360, 480], index=5)
        submitted = st.form_submit_button("Analyse application", type="primary", use_container_width=True)

    if submitted:
        applicant = {
            "Gender": gender,
            "Married": married,
            "Dependents": dependents,
            "Education": education,
            "Self_Employed": self_employed,
            "ApplicantIncome": applicant_income,
            "CoapplicantIncome": coapplicant_income,
            "LoanAmount": loan_amount,
            "Loan_Amount_Term": loan_term,
            "Credit_History": 1.0 if credit_history_choice.startswith("Meets") else 0.0,
            "Property_Area": property_area,
        }
        prediction, confidence = predict_applicant(model, applicant)
        st.divider()
        r1, r2 = st.columns([1, 1.5], gap="large")
        with r1:
            st.markdown("### Prediction result")
            if prediction == "Approved":
                st.success("Model prediction: APPROVED", icon="✅")
            else:
                st.warning("Model prediction: REJECTED", icon="⚠️")
            st.metric("Estimated probability of predicted class", f"{confidence * 100:.1f}%")
            probability_row = model.predict_proba(pd.DataFrame([applicant], columns=FEATURE_COLUMNS))[0]
            class_names = list(model.named_steps["classifier"].classes_)
            prob_df = pd.DataFrame({"Class": class_names, "Estimated probability": probability_row})
            fig = px.bar(prob_df, x="Class", y="Estimated probability", color="Class", text=prob_df["Estimated probability"].map(lambda v: f"{v * 100:.1f}%"), color_discrete_map={"Approved": "#2563eb", "Rejected": "#f97316"})
            fig.update_traces(textposition="outside", cliponaxis=False)
            fig.update_layout(yaxis_tickformat=".0%", yaxis_range=[0, 1.18], showlegend=False, height=300, margin=dict(l=5, r=5, t=10, b=10), xaxis_title="", yaxis_title="Model-estimated probability")
            st.plotly_chart(fig, use_container_width=True)
        with r2:
            st.markdown("### Application summary")
            summary = pd.DataFrame({"Field": list(applicant.keys()), "Entered value": list(applicant.values())})
            st.dataframe(summary, use_container_width=True, hide_index=True)
            st.markdown("<div class='insight'><b>Interpretation:</b> the model learned patterns from the available labelled dataset. Its probability is not a bank guarantee, and it may reflect bias or limitations in the training data.</div>", unsafe_allow_html=True)

elif page == "Model Performance":
    hero()
    st.subheader("Model evaluation")
    st.markdown("<div class='section-intro'>Model selection uses cross-validation on the training partition. Final metrics are calculated on a separate held-out test partition.</div>", unsafe_allow_html=True)

    m1, m2, m3, m4, m5 = st.columns(5)
    m1.metric("Selected model", metrics["model_name"])
    m2.metric("Accuracy", f"{metrics['accuracy']:.3f}")
    m3.metric("Precision", f"{metrics['precision']:.3f}")
    m4.metric("Recall", f"{metrics['recall']:.3f}")
    m5.metric("F1-score", f"{metrics['f1']:.3f}")
    st.caption(f"Train/test split: {metrics['train_size']:,} / {metrics['test_size']:,} rows · {metrics['cv_folds']}-fold training cross-validation · CV F1: {metrics['cv_f1_mean']:.3f} ± {metrics['cv_f1_std']:.3f}")

    st.markdown("### Classifier comparison")
    display_comparison = comparison.copy()
    metric_cols = [c for c in display_comparison.columns if c != "Model"]
    st.dataframe(display_comparison.style.format({column: "{:.3f}" for column in metric_cols}), use_container_width=True, hide_index=True)
    st.caption("CV F1 determines the selected model. Test metrics are shown for transparency and are not used to choose the winner.")

    left, right = st.columns(2, gap="large")
    with left:
        st.markdown("### Confusion matrix")
        cm_df = pd.DataFrame(cm, index=["Actual rejected", "Actual approved"], columns=["Predicted rejected", "Predicted approved"])
        fig = px.imshow(cm_df, text_auto=True, aspect="auto", color_continuous_scale=[[0, "#eff6ff"], [1, "#3730a3"]], labels=dict(x="Predicted class", y="Actual class", color="Count"))
        fig.update_layout(height=340, margin=dict(l=8, r=8, t=10, b=10))
        st.plotly_chart(fig, use_container_width=True)
    with right:
        st.markdown("### ROC curve")
        if len(np.unique(y_test)) == 2:
            fpr, tpr, _ = roc_curve((y_test == "Approved").astype(int), y_prob)
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=fpr, y=tpr, mode="lines", name=f"Selected model · AUC {metrics['roc_auc']:.3f}", line=dict(width=3, color="#4f46e5")))
            fig.add_trace(go.Scatter(x=[0, 1], y=[0, 1], mode="lines", name="Random baseline", line=dict(dash="dash", color="#94a3b8")))
            fig.update_layout(xaxis_title="False positive rate", yaxis_title="True positive rate", xaxis_range=[0, 1], yaxis_range=[0, 1.02], height=340, margin=dict(l=8, r=8, t=10, b=10), legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0))
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("ROC curve needs both classes in the test split.")

    st.markdown("### Most influential transformed features")
    if len(importance):
        feature_col = "Importance" if "Importance" in importance.columns else "Coefficient"
        sorted_importance = importance.copy().sort_values(feature_col, key=lambda series: series.abs(), ascending=True)
        fig = px.bar(sorted_importance, x=feature_col, y="Feature", orientation="h", color=feature_col, color_continuous_scale=["#f97316", "#cbd5e1", "#4f46e5"])
        fig.update_layout(height=max(360, 22 * len(sorted_importance)), coloraxis_showscale=False, margin=dict(l=8, r=8, t=10, b=8), yaxis_title="", xaxis_title=feature_col)
        st.plotly_chart(fig, use_container_width=True)
    st.markdown("<div class='insight'><b>Metric guide:</b> accuracy measures overall correctness; precision tells how many predicted approvals were actually approved; recall measures how many actual approvals were found; F1 balances precision and recall; ROC-AUC measures ranking quality across thresholds.</div>", unsafe_allow_html=True)

elif page == "Project Guide":
    hero()
    st.subheader("Project brief and viva notes")
    st.markdown("<div class='section-intro'>Use this page to explain the problem, dataset, methodology, algorithms, limitations, and end-to-end flow during your presentation.</div>", unsafe_allow_html=True)

    tab1, tab2, tab3 = st.tabs(["Problem & data", "ML workflow", "Viva quick notes"])
    with tab1:
        st.markdown("### Problem statement")
        st.write("Loan applications contain numerical and categorical details. This project demonstrates how supervised classification models can learn associations from labelled examples and estimate the historical loan-status class for a new record.")
        st.markdown("### Aim")
        st.write("To build an interactive loan approval classification application with exploratory data analysis, preprocessing, model comparison, evaluation, and a prediction interface.")
        st.markdown("### Dataset and target")
        st.write("The bundled file contains synthetic educational applicant records, generated by `scripts/generate_demo_data.py` using a fixed random seed. The schema follows common loan-prediction fields. The target variable is `Loan_Status`, normalized to Approved/Rejected by the app.")
        st.write("Features: gender, marital status, dependents, education, self-employment, applicant income, co-applicant income, loan amount, loan term, credit history, and property area. `Loan_ID` is an identifier and is not used as a predictor.")
        st.info("For an alternate experiment, upload a compatible labelled CSV such as the publicly documented Analytics Vidhya Loan Prediction Problem schema. Public mirror links and attribution notes are listed in README.md.")
    with tab2:
        st.markdown("### Workflow required by the assignment")
        st.code("Dataset → EDA → Preprocessing → Train/Test Split → ML Model → Evaluation → Results → Conclusion", language="text")
        st.markdown("**Preprocessing:** numeric missing values are filled with the training-set median; categorical missing values use the most frequent training value; numeric features are standardized; categorical features are one-hot encoded. These steps live inside an sklearn pipeline to reduce data leakage.")
        st.markdown("**Models:** Logistic Regression is a linear probabilistic classifier. Random Forest combines many decision trees and can capture non-linear patterns. The model with the higher mean F1-score under cross-validation on training data is selected.")
        st.markdown("**Evaluation:** a stratified 75/25 train/test split is used. Report accuracy, precision, recall, F1-score, ROC-AUC, a confusion matrix, ROC curve, class distribution, missing-value checks, and 2–3 EDA graphs.")
    with tab3:
        st.markdown("### Explain it in simple words")
        st.markdown("- **Classification:** predicting one of the categories—Approved or Rejected.")
        st.markdown("- **Target variable:** `Loan_Status`, the class the model learns to predict.")
        st.markdown("- **Imputation:** filling missing feature values with a simple training-data statistic.")
        st.markdown("- **One-hot encoding:** representing categories as numeric indicator columns.")
        st.markdown("- **Train/test split:** train on one part, measure final performance on unseen held-out rows.")
        st.markdown("- **Cross-validation:** repeat training/validation splits within the training set to compare candidate models more reliably.")
        st.markdown("- **F1-score:** harmonic mean of precision and recall; useful when class balance matters.")
        st.markdown("- **Limitation:** synthetic labels are simulated. Strong scores on this dataset do not prove real-world creditworthiness or fairness.")

    st.divider()
    st.markdown("### Teacher's checklist")
    checklist = [
        ("Topic, dataset, problem and objective", True),
        ("Target variable and dataset source", True),
        ("EDA, missing-value inspection and duplicate checks", True),
        ("At least three relevant visualizations", True),
        ("Preprocessing for numerical and categorical features", True),
        ("Train/test split and classification algorithms", True),
        ("Prediction interface", True),
        ("Evaluation metrics, plots, results and conclusion", True),
    ]
    for item, done in checklist:
        st.markdown(f"{'✅' if done else '⬜'} {item}")
    st.caption("The checklist refers to features implemented in this application. Replace or supplement the synthetic data with the dataset required by your instructor if a real public dataset is mandatory.")

st.divider()
st.caption("CrediScope · SMLDS Mini Project · Educational prototype only · Do not use for actual lending decisions.")
