"""Reusable data validation, preprocessing, training, and prediction helpers."""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.metrics import make_scorer

TARGET = "Loan_Status"
ID_COLUMN = "Loan_ID"
FEATURE_COLUMNS = [
    "Gender",
    "Married",
    "Dependents",
    "Education",
    "Self_Employed",
    "ApplicantIncome",
    "CoapplicantIncome",
    "LoanAmount",
    "Loan_Amount_Term",
    "Credit_History",
    "Property_Area",
]
NUMERIC_FEATURES = [
    "ApplicantIncome",
    "CoapplicantIncome",
    "LoanAmount",
    "Loan_Amount_Term",
]
CATEGORICAL_FEATURES = [
    "Gender",
    "Married",
    "Dependents",
    "Education",
    "Self_Employed",
    "Credit_History",
    "Property_Area",
]
TARGET_LABELS = ["Rejected", "Approved"]


def load_dataset(path: str) -> pd.DataFrame:
    """Read a CSV file and normalize its target labels for the UI."""
    return normalize_dataset(pd.read_csv(path))


def normalize_dataset(data: pd.DataFrame) -> pd.DataFrame:
    """Clean superficial formatting differences and normalize target labels.

    Compatible targets include Y/N, Yes/No, 1/0, Approved/Rejected.
    The function does not impute feature data: missingness stays visible for EDA
    and is handled inside each fitted sklearn pipeline to avoid leakage.
    """
    if not isinstance(data, pd.DataFrame):
        raise TypeError("The dataset must be a pandas DataFrame.")

    cleaned = data.copy()
    cleaned.columns = [str(col).strip() for col in cleaned.columns]

    for column in cleaned.select_dtypes(include=["object", "string"]).columns:
        cleaned[column] = cleaned[column].map(
            lambda value: value.strip() if isinstance(value, str) else value
        )
        cleaned[column] = cleaned[column].replace({"": np.nan, "?": np.nan, "NA": np.nan, "N/A": np.nan})

    if TARGET in cleaned.columns:
        raw = cleaned[TARGET]
        mapping = {
            "y": "Approved",
            "yes": "Approved",
            "approved": "Approved",
            "1": "Approved",
            "1.0": "Approved",
            "true": "Approved",
            "n": "Rejected",
            "no": "Rejected",
            "rejected": "Rejected",
            "0": "Rejected",
            "0.0": "Rejected",
            "false": "Rejected",
        }
        def map_target(value):
            if pd.isna(value):
                return np.nan
            text = str(value).strip().lower()
            return mapping.get(text, str(value).strip())
        cleaned[TARGET] = raw.map(map_target)

    for column in NUMERIC_FEATURES + ["Credit_History"]:
        if column in cleaned.columns:
            cleaned[column] = pd.to_numeric(cleaned[column], errors="coerce")

    # Treat binary credit history as a category in the modeling pipeline, but
    # normalize 0/1 representations so upload formats remain compatible.
    if "Credit_History" in cleaned.columns:
        cleaned["Credit_History"] = cleaned["Credit_History"].replace({0: 0.0, 1: 1.0})

    return cleaned


def validate_dataset(data: pd.DataFrame) -> bool:
    """Raise a user-readable ValueError when the input schema is incompatible."""
    cleaned = normalize_dataset(data)
    required = FEATURE_COLUMNS + [TARGET]
    missing = [column for column in required if column not in cleaned.columns]
    if missing:
        raise ValueError(
            "Missing required columns: " + ", ".join(missing) +
            ". Use the template columns shown in the README."
        )
    if cleaned.empty:
        raise ValueError("The dataset has no rows.")
    if cleaned[TARGET].isna().any():
        raise ValueError("Loan_Status contains missing labels. Remove rows without a known target first.")
    labels = set(cleaned[TARGET].astype(str).unique())
    if not labels.issubset({"Approved", "Rejected"}) or len(labels) < 2:
        raise ValueError("Loan_Status must contain both Approved and Rejected labels (or Y/N, 1/0).")
    return True


def build_pipeline(model_kind: str) -> Pipeline:
    """Build preprocessing + estimator as a single leakage-safe pipeline."""
    numeric_pipeline = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
        ]
    )
    categorical_pipeline = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore")),
        ]
    )
    preprocessor = ColumnTransformer(
        transformers=[
            ("numeric", numeric_pipeline, NUMERIC_FEATURES),
            ("categorical", categorical_pipeline, CATEGORICAL_FEATURES),
        ],
        remainder="drop",
    )

    if model_kind == "Logistic Regression":
        classifier = LogisticRegression(
            max_iter=2000,
            class_weight="balanced",
            random_state=42,
        )
    elif model_kind == "Random Forest":
        classifier = RandomForestClassifier(
            n_estimators=180,
            max_depth=8,
            min_samples_leaf=3,
            class_weight="balanced",
            random_state=42,
            n_jobs=-1,
        )
    else:
        raise ValueError(f"Unknown model: {model_kind}")

    return Pipeline(steps=[("preprocess", preprocessor), ("classifier", classifier)])


def _metrics_for(model: Pipeline, X_test: pd.DataFrame, y_test: pd.Series) -> dict:
    y_pred = model.predict(X_test)
    classes = list(model.named_steps["classifier"].classes_)
    probabilities = model.predict_proba(X_test)
    approved_index = classes.index("Approved")
    approved_probability = probabilities[:, approved_index]
    y_approved = (y_test == "Approved").astype(int)
    auc = float(roc_auc_score(y_approved, approved_probability)) if y_approved.nunique() == 2 else None
    return {
        "accuracy": float(accuracy_score(y_test, y_pred)),
        "precision": float(precision_score(y_test, y_pred, pos_label="Approved", zero_division=0)),
        "recall": float(recall_score(y_test, y_pred, pos_label="Approved", zero_division=0)),
        "f1": float(f1_score(y_test, y_pred, pos_label="Approved", zero_division=0)),
        "roc_auc": auc,
        "y_pred": y_pred,
        "y_prob": approved_probability,
    }


def train_evaluate_model(data: pd.DataFrame):
    """Compare classifiers via CV on training data; evaluate the winner once.

    Returns: model, metrics, X_test, y_test, y_pred, y_prob, comparison_table.
    The held-out test split is not used for model selection.
    """
    cleaned = normalize_dataset(data)
    validate_dataset(cleaned)
    working = cleaned[FEATURE_COLUMNS + [TARGET]].copy()
    X = working[FEATURE_COLUMNS]
    y = working[TARGET].astype(str)

    class_counts = y.value_counts()
    if class_counts.min() < 2:
        raise ValueError("At least two examples of each target class are required.")

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.25,
        random_state=42,
        stratify=y,
    )

    min_train_class = int(y_train.value_counts().min())
    n_splits = min(5, min_train_class)
    if n_splits < 2:
        raise ValueError("Not enough examples in the training set for cross-validation.")
    cv = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)
    f1_approved = make_scorer(f1_score, pos_label="Approved", zero_division=0)

    candidates = []
    comparisons = []
    for model_name in ["Logistic Regression", "Random Forest"]:
        pipeline = build_pipeline(model_name)
        cv_scores = cross_val_score(
            pipeline,
            X_train,
            y_train,
            cv=cv,
            scoring=f1_approved,
            n_jobs=1,
        )
        pipeline.fit(X_train, y_train)
        model_metrics = _metrics_for(pipeline, X_test, y_test)
        candidate = {
            "name": model_name,
            "model": pipeline,
            "cv_f1_mean": float(np.mean(cv_scores)),
            "cv_f1_std": float(np.std(cv_scores)),
            "metrics": model_metrics,
        }
        candidates.append(candidate)
        comparisons.append(
            {
                "Model": model_name,
                "CV F1 (mean)": candidate["cv_f1_mean"],
                "CV F1 (std)": candidate["cv_f1_std"],
                "Test accuracy": model_metrics["accuracy"],
                "Test precision": model_metrics["precision"],
                "Test recall": model_metrics["recall"],
                "Test F1": model_metrics["f1"],
                "Test ROC-AUC": model_metrics["roc_auc"],
            }
        )

    candidates.sort(key=lambda candidate: candidate["cv_f1_mean"], reverse=True)
    selected = candidates[0]
    selected_metrics = selected["metrics"]
    metrics = {
        "model_name": selected["name"],
        "accuracy": selected_metrics["accuracy"],
        "precision": selected_metrics["precision"],
        "recall": selected_metrics["recall"],
        "f1": selected_metrics["f1"],
        "roc_auc": selected_metrics["roc_auc"],
        "cv_f1_mean": selected["cv_f1_mean"],
        "cv_f1_std": selected["cv_f1_std"],
        "cv_folds": n_splits,
        "train_size": len(X_train),
        "test_size": len(X_test),
    }
    y_pred = selected_metrics["y_pred"]
    y_prob = selected_metrics["y_prob"]
    comparison_table = pd.DataFrame(comparisons).sort_values("CV F1 (mean)", ascending=False).reset_index(drop=True)

    return selected["model"], metrics, X_test, y_test, y_pred, y_prob, comparison_table


def predict_applicant(model: Pipeline, applicant: dict) -> tuple[str, float]:
    """Return the predicted class and its estimated probability for one applicant."""
    row_data = {key: applicant.get(key, np.nan) for key in FEATURE_COLUMNS}
    row = pd.DataFrame([row_data], columns=FEATURE_COLUMNS)
    predicted = str(model.predict(row)[0])
    probabilities = model.predict_proba(row)[0]
    classes = list(model.named_steps["classifier"].classes_)
    confidence = float(probabilities[classes.index(predicted)])
    return predicted, confidence


def get_feature_importance(model: Pipeline, top_n: int = 18) -> pd.DataFrame:
    """Return transformed model features ranked by absolute model contribution."""
    preprocessor = model.named_steps["preprocess"]
    classifier = model.named_steps["classifier"]
    try:
        names = preprocessor.get_feature_names_out()
    except Exception:
        names = np.array([f"Feature {i + 1}" for i in range(len(classifier.feature_importances_))])

    if hasattr(classifier, "feature_importances_"):
        values = classifier.feature_importances_
        score_name = "Importance"
    elif hasattr(classifier, "coef_"):
        values = classifier.coef_[0]
        score_name = "Coefficient"
    else:
        return pd.DataFrame(columns=["Feature", "Score"])

    result = pd.DataFrame({"Feature": names, score_name: values})
    result["Feature"] = (
        result["Feature"].astype(str)
        .str.replace("numeric__", "", regex=False)
        .str.replace("categorical__", "", regex=False)
    )
    result["Magnitude"] = result[score_name].abs()
    return result.sort_values("Magnitude", ascending=False).head(top_n).drop(columns="Magnitude").reset_index(drop=True)
