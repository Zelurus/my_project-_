"""Optional helper: download the public loan-prediction CSV for local experiments.

This keeps the synthetic demo dataset intact. Review the upstream dataset terms
before using or redistributing downloaded data.
"""
from pathlib import Path
from urllib.request import Request, urlopen

URL = "https://raw.githubusercontent.com/shrikant-temburwar/Loan-Prediction-Dataset/master/train.csv"
ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "data" / "loan_applications_public.csv"


def main() -> None:
    request = Request(URL, headers={"User-Agent": "CrediScope educational project/1.0"})
    try:
        with urlopen(request, timeout=20) as response:
            content = response.read()
    except Exception as exc:
        raise SystemExit(
            "Could not download the reference CSV. Check your internet connection "
            "or download the raw CSV from the source linked in README.md.\n"
            f"Details: {exc}"
        ) from exc

    if b"Loan_ID" not in content[:500] or b"Loan_Status" not in content[:500]:
        raise SystemExit("Downloaded file does not look like the expected loan prediction CSV.")

    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_bytes(content)
    print(f"Saved {len(content):,} bytes to: {OUTPUT}")
    print("In CrediScope, use the sidebar uploader and select loan_applications_public.csv.")
    print("The bundled synthetic loan_applications.csv has not been changed.")


if __name__ == "__main__":
    main()
