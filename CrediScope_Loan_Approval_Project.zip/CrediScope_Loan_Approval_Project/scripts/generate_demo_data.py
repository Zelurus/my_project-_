"""Generate a deterministic, synthetic loan-application dataset for this demo.

This script does not download or reproduce real applicants' data. The schema is
inspired by commonly used educational loan-approval datasets. Outcomes are
simulated with probabilistic rules solely to demonstrate an ML workflow.
"""
from pathlib import Path
import numpy as np
import pandas as pd

SEED = 42
ROWS = 800
ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "data" / "loan_applications.csv"


def generate_dataset(rows: int = ROWS, seed: int = SEED) -> pd.DataFrame:
    rng = np.random.default_rng(seed)

    gender = rng.choice(["Male", "Female"], rows, p=[0.78, 0.22])
    married = rng.choice(["Yes", "No"], rows, p=[0.65, 0.35])
    dependents = rng.choice(["0", "1", "2", "3+"], rows, p=[0.56, 0.17, 0.16, 0.11])
    education = rng.choice(["Graduate", "Not Graduate"], rows, p=[0.79, 0.21])
    self_employed = rng.choice(["Yes", "No"], rows, p=[0.15, 0.85])
    property_area = rng.choice(["Urban", "Semiurban", "Rural"], rows, p=[0.33, 0.39, 0.28])

    applicant_income = np.clip(rng.lognormal(mean=8.25, sigma=0.58, size=rows), 500, 80000).round().astype(int)
    coapplicant_income = np.where(
        rng.random(rows) < 0.43,
        0,
        np.clip(rng.lognormal(mean=8.05, sigma=0.68, size=rows), 250, 45000),
    ).round().astype(int)

    income_total = applicant_income + coapplicant_income
    loan_amount = np.clip(income_total * rng.normal(0.024, 0.006, rows), 25, 700).round().astype(float)
    loan_term = rng.choice([60, 120, 180, 240, 300, 360, 480], rows, p=[0.02, 0.03, 0.05, 0.04, 0.07, 0.75, 0.04]).astype(float)
    credit_history = rng.choice([0.0, 1.0], rows, p=[0.18, 0.82])

    # Create simulated target outcomes with noise so the classification task is
    # learnable but not perfectly deterministic. This is not a lending policy.
    dep_count = np.array([3 if d == "3+" else int(d) for d in dependents])
    affordability = np.log1p(income_total) - np.log1p(loan_amount * 1000 / np.maximum(loan_term, 12))
    area_effect = np.select(
        [property_area == "Semiurban", property_area == "Urban"],
        [0.22, 0.04],
        default=-0.08,
    )
    education_effect = np.where(education == "Graduate", 0.12, -0.05)
    employment_effect = np.where(self_employed == "Yes", -0.10, 0.03)
    married_effect = np.where(married == "Yes", 0.08, 0.0)
    logit = (
        -1.75
        + 2.05 * credit_history
        + 0.27 * affordability
        + education_effect
        + employment_effect
        + married_effect
        + area_effect
        - 0.065 * dep_count
        + rng.normal(0, 0.28, rows)
    )
    approval_probability = 1 / (1 + np.exp(-logit))
    approved = rng.random(rows) < approval_probability

    frame = pd.DataFrame(
        {
            "Loan_ID": [f"DEMO{idx:05d}" for idx in range(1, rows + 1)],
            "Gender": gender,
            "Married": married,
            "Dependents": dependents,
            "Education": education,
            "Self_Employed": self_employed,
            "ApplicantIncome": applicant_income,
            "CoapplicantIncome": coapplicant_income,
            "LoanAmount": loan_amount,
            "Loan_Amount_Term": loan_term,
            "Credit_History": credit_history,
            "Property_Area": property_area,
            "Loan_Status": np.where(approved, "Y", "N"),
        }
    )

    # Add realistic missingness to demonstrate EDA and pipeline-based imputation.
    missing_rates = {
        "Gender": 0.018,
        "Married": 0.012,
        "Dependents": 0.025,
        "Self_Employed": 0.045,
        "LoanAmount": 0.035,
        "Loan_Amount_Term": 0.022,
        "Credit_History": 0.075,
    }
    for column, rate in missing_rates.items():
        mask = rng.random(rows) < rate
        frame.loc[mask, column] = np.nan

    return frame


if __name__ == "__main__":
    data = generate_dataset()
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    data.to_csv(OUTPUT, index=False)
    print(f"Saved {len(data):,} synthetic demo applications to {OUTPUT}")
    print("Status counts:")
    print(data["Loan_Status"].value_counts())
