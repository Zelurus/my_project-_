"""Quick smoke tests for the data and machine-learning backend."""
import unittest
from pathlib import Path

import pandas as pd

from model_utils import load_dataset, validate_dataset, train_evaluate_model, predict_applicant

ROOT = Path(__file__).resolve().parents[1]


class CrediScopeModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = load_dataset(str(ROOT / "data" / "loan_applications.csv"))

    def test_demo_dataset_has_valid_schema(self):
        self.assertTrue(validate_dataset(self.data))
        self.assertEqual(len(self.data), 800)

    def test_target_labels_are_normalized(self):
        self.assertEqual(set(self.data["Loan_Status"].unique()), {"Approved", "Rejected"})

    def test_training_and_prediction_work(self):
        model, metrics, *_ = train_evaluate_model(self.data)
        self.assertIn(metrics["model_name"], {"Logistic Regression", "Random Forest"})
        self.assertGreaterEqual(metrics["accuracy"], 0.0)
        self.assertLessEqual(metrics["accuracy"], 1.0)
        applicant = {
            "Gender": "Female",
            "Married": "No",
            "Dependents": "0",
            "Education": "Graduate",
            "Self_Employed": "No",
            "ApplicantIncome": 5500,
            "CoapplicantIncome": 1500,
            "LoanAmount": 140,
            "Loan_Amount_Term": 360,
            "Credit_History": 1.0,
            "Property_Area": "Semiurban",
        }
        label, probability = predict_applicant(model, applicant)
        self.assertIn(label, {"Approved", "Rejected"})
        self.assertGreaterEqual(probability, 0.0)
        self.assertLessEqual(probability, 1.0)


if __name__ == "__main__":
    unittest.main()
